package org.example.question2;

import java.lang.reflect.Field;

public class SqlGenerator {

    // CREATE TABLE
    public static String createTableSql(
            Class<?> clazz) {

        StringBuilder sb =
                new StringBuilder();

        sb.append("CREATE TABLE ");
        sb.append(clazz.getSimpleName());
        sb.append(" (");

        Field[] fields =
                clazz.getDeclaredFields();

        for (Field field : fields) {

            Column column =
                    field.getAnnotation(Column.class);

            if (column == null) continue;

            sb.append(field.getName());

            Class<?> type =
                    field.getType();

            if (type == String.class) {

                int len =
                        column.MaxLength() > 0
                                ? column.MaxLength()
                                : 255;

                sb.append(" VARCHAR(")
                        .append(len)
                        .append(")");

            } else if (type == Integer.class) {

                sb.append(" INT");

            } else if (type == Boolean.class) {

                sb.append(" BOOLEAN");
            }

            if (!column.Nullable()) {

                sb.append(" NOT NULL");
            }

            sb.append(",");
        }

        sb.deleteCharAt(sb.length() - 1);

        sb.append(")");

        return sb.toString();
    }

    // INSERT
    public static String insertSql(
            Class<?> clazz) {

        StringBuilder sb =
                new StringBuilder();

        sb.append("INSERT INTO ");
        sb.append(clazz.getSimpleName());
        sb.append(" VALUES(");

        Field[] fields =
                clazz.getDeclaredFields();

        for (Field field : fields) {

            if (field.getAnnotation(Column.class)
                    != null) {

                sb.append("?,");
            }
        }

        sb.deleteCharAt(sb.length() - 1);

        sb.append(")");

        return sb.toString();
    }

    // UPDATE
    public static String updateSql(
            Class<?> clazz) {

        StringBuilder sb =
                new StringBuilder();

        sb.append("UPDATE ");
        sb.append(clazz.getSimpleName());
        sb.append(" SET ");

        Field[] fields =
                clazz.getDeclaredFields();

        for (Field field : fields) {

            if (field.getAnnotation(Column.class)
                    != null) {

                sb.append(field.getName());
                sb.append("=?,");
            }
        }

        sb.deleteCharAt(sb.length() - 1);

        sb.append(" WHERE idNo=?");

        return sb.toString();
    }

    // DELETE
    public static String deleteSql(
            Class<?> clazz) {

        return "DELETE FROM "
                + clazz.getSimpleName()
                + " WHERE idNo=?";
    }
}

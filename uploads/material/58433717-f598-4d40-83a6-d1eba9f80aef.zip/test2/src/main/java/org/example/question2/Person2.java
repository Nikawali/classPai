package org.example.question2;

import org.example.Label;

@Label("人员")
public class Person2 {

    @Column(Label = "姓名", Nullable = false, MaxLength = 20, MinLength = 2)
    private String name;

    @Column(Label = "性别", Nullable = false, MaxLength = 2)
    private String gender;

    @Column(Label = "年龄", Nullable = false, MaxValue = 150, MinValue = 0)
    private Integer age;

    @Column(Label = "身份证号", Nullable = false, MaxLength = 18, MinLength = 18)
    private String idNo;

    @Column(Label = "是否已婚")
    private Boolean isMarried;

    public Person2() {

    }

    public Person2(String name, String gender, Integer age, String idNo, Boolean isMarried) {
     setName(name);
     setGender(gender);
     setAge(age);
     setIdNo(idNo);
     setIsMarried(isMarried);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(Integer age) {
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("年龄必须在0-120之间");
        }
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public void setIsMarried(Boolean isMarried) {
        this.isMarried = isMarried;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getIdNo() {
        return idNo;
    }

    public Boolean getIsMarried() {
        return isMarried;
    }
}
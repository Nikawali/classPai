package org.example;


public class Main {
    public static void main(String[] args) {

        Person person = new Person();

        PersonAction input = new PersonInput();
        PersonAction display = new PersonDisplay();

        person = input.process(person);
        display.process(person);
    }
}
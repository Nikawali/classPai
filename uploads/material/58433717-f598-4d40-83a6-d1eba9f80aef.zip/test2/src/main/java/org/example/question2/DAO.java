package org.example.question2;
import org.example.Person;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class DAO {

    /**
     * 插入数据
     */
    public void insertPerson(Person2 person2)
            throws Exception {

        Connection conn =
                JdbcUtil.getConnection();

        String sql =
                SqlGenerator.insertSql(Person2.class);
        System.out.println(sql);

        PreparedStatement ps =
                conn.prepareStatement(sql);

        Field[] fields =
                Person2.class.getDeclaredFields();

        int index = 1;

        for (Field field : fields) {

            field.setAccessible(true);

            if (field.getAnnotation(Column.class)
                    != null) {

                Object value =
                        field.get(person2);

                ps.setObject(index++, value);
            }
        }

        ps.executeUpdate();

        ps.close();
        conn.close();
    }

    /**
     * 更新数据（根据 idNo）
     */
    public void updatePerson(Person2 person2)
            throws Exception {

        Connection conn =
                JdbcUtil.getConnection();

        String sql =
                SqlGenerator.updateSql(Person2.class);
        System.out.println(sql);

        PreparedStatement ps =
                conn.prepareStatement(sql);

        Field[] fields =
                Person2.class.getDeclaredFields();

        int index = 1;

        String idValue = null;

        for (Field field : fields) {

            field.setAccessible(true);

            if (field.getAnnotation(Column.class)
                    != null) {

                Object value =
                        field.get(person2);

                ps.setObject(index++, value);

                // 记录 idNo
                if (field.getName()
                        .equals("idNo")) {

                    idValue = value.toString();
                }
            }
        }

        // WHERE idNo=?
        ps.setObject(index, idValue);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }

    /**
     * 删除数据
     */
    public void deletePerson(String idNo)
            throws Exception {

        Connection conn =
                JdbcUtil.getConnection();

        String sql =
                SqlGenerator.deleteSql(Person2.class);
        System.out.println(sql);

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.setString(1, idNo);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }

   /* /**
     */
/*    public void createTable()
            throws Exception {

        Connection conn =
                JdbcUtil.getConnection();

        String sql =
                SqlGenerator.createTableSql(
                        Person.class);

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }*/

}
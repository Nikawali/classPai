package org.example.question2;


public class Main {

    public static void main(String[] args) {

        try {

            // 创建Person对象
            Person2 person2 =new Person2();
            // 输入数据（带校验）
            PersonAction2 input =
                    new PersonInput2();

            person2 = input.process(person2);

          /*  // 显示创建表SQL
            System.out.println("创建表SQL：");
            System.out.println(
                    SqlGenerator.createTableSql(
                            Person2.class
                    )
            );*/

            DAO dao =
                    new DAO();


            // 插入数据
            dao.insertPerson(person2);

            System.out.println("插入成功");

/*            //  修改数据
            person2.setName("wangxu" +
                    "");

            dao.updatePerson(person2);

            System.out.println("更新成功");*/

            /*// 删除数据
            dao.deletePerson(
                    person2.getIdNo()
            );*/

            /*System.out.println("删除成功");*/

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
}
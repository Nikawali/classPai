package org.example.question2;

import java.sql.Connection;
import java.sql.DriverManager;

public class JdbcUtil {

    static final String url =
            "jdbc:mysql://localhost:3306/test?useSSL=false&serverTimezone=UTC";

    static final String user = "root";

    static final String password = "qwertYUIOP200512";

    public static Connection getConnection()
            throws Exception {

        Class.forName(
                "com.mysql.cj.jdbc.Driver"
        );

        return DriverManager.getConnection(
                url,
                user,
                password
        );
    }
}
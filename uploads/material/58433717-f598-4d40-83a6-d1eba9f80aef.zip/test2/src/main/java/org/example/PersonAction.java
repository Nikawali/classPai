package org.example;

public interface PersonAction {
    Person process(Person person);
}
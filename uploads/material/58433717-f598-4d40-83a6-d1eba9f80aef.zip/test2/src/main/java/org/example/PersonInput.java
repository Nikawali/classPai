package org.example;


import java.lang.reflect.Field;
import java.util.Scanner;

public class PersonInput implements PersonAction {

    @Override
    public Person process(Person person) {

        Scanner scanner = new Scanner(System.in);

        Class<?> clazz = person.getClass();

        Field[] fields = clazz.getDeclaredFields();

        try {
            for (Field field : fields) {

                field.setAccessible(true);//关闭访问权限

                // 获取注解
                Label label = field.getAnnotation(Label.class);
                if (label == null) continue;

                System.out.print("请输入" + label.value() + "：");

                Class<?> type = field.getType();

                if (type == String.class) {
                    field.set(person, scanner.nextLine());
                } else if (type == Integer.class) {
                    field.set(person, Integer.parseInt(scanner.nextLine()));
                } else if (type == Boolean.class) {
                    field.set(person, (scanner.nextLine().equals("已婚")));
                }
                  }
        } catch (Exception e) {
              e.printStackTrace();
        }

        return person;
    }
}


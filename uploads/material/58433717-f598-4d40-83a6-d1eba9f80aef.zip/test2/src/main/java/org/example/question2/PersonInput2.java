package org.example.question2;

import org.example.Person;
import java.lang.reflect.Field;
import java.util.Scanner;

public class PersonInput2 implements PersonAction2 {

    @Override
    public Person2 process(Person2 person2) {

        Scanner scanner = new Scanner(System.in);

        Field[] fields = person2.getClass().getDeclaredFields();

        try {

            for (Field field : fields) {

                field.setAccessible(true);

                Column column =
                        field.getAnnotation(Column.class);

                if (column == null) continue;

                while (true) {

                    System.out.print(
                            "请输入" + column.Label() + "："
                    );

                    String input =
                            scanner.nextLine();

                    // ① 非空校验
                    if (!column.Nullable()
                            && input.isEmpty()) {

                        System.out.println(
                                column.Label()
                                        + "不能为空"
                        );
                        continue;
                    }

                    Class<?> type =
                            field.getType();

                    // ② String 校验
                    if (type == String.class) {

                        int len = input.length();

                        if (column.MaxLength() > 0
                                && len > column.MaxLength()) {

                            System.out.println(
                                    "长度不能超过"
                                            + column.MaxLength()
                            );
                            continue;
                        }

                        if (column.MinLength() > 0
                                && len < column.MinLength()) {

                            System.out.println(
                                    "长度不能小于"
                                            + column.MinLength()
                            );
                            continue;
                        }

                        field.set(person2, input);
                        break;
                    }

                    // ③ Integer 校验
                    else if (type == Integer.class) {

                        int value =
                                Integer.parseInt(input);

                        if (value > column.MaxValue()
                                || value < column.MinValue()) {

                            System.out.println(
                                    "数值超出范围"
                            );
                            continue;
                        }

                        field.set(person2, value);
                        break;
                    }

                    // ④ Boolean
                    else if (type == Boolean.class) {

                        field.set(person2,
                                input.equals("已婚"));

                        break;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return person2;
    }
}
package org.example.question2;


public interface PersonAction2 {
    org.example.question2.Person2 process(Person2 person2);
}
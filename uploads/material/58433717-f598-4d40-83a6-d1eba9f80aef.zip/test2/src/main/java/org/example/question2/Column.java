package org.example.question2;

import java.lang.annotation.*;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {

    String Label();          // 显示名称

    boolean Nullable() default true;

    int MaxLength() default -1;

    int MinLength() default -1;

    int MaxValue() default Integer.MAX_VALUE;

    int MinValue() default Integer.MIN_VALUE;
}
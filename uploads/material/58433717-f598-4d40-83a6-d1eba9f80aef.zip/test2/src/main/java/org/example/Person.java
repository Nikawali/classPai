package org.example;

@Label("人员")
public class Person  {
    @Label("姓名")
    private String name;
    @Label("性别")
    private String gender;
    @Label("年龄")
    private Integer age;
    @Label("身份证号")
    private String idNo;
    @Label("婚姻状况(已婚/未婚)")
    private Boolean isMarried;

    public Person() {

    }

    public Person(String name, String gender, Integer age,String idNo,Boolean isMarried) {
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.idNo=idNo;
        this.isMarried=isMarried;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(Integer age) {
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("年龄必须在0-120之间");
        }
        this.age = age;
    }

    public void setGender(String gender){
        this.gender=gender;
    }

    public void setIdNo(String idNo){
        this.idNo=idNo;
    }

    public void setIsMarried(Boolean isMarried){
        this.isMarried=isMarried;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getIdNo(){
        return idNo;
    }

    public Boolean getIsMarried(){
        return isMarried;
    }
}
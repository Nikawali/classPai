package org.example;

import java.lang.reflect.Field;

public class PersonDisplay implements PersonAction {

    @Override
    public Person process(Person person) {

        Class<?> clazz = person.getClass();

        // 类注解
        Label classLabel = clazz.getAnnotation(Label.class);
        if (classLabel != null) {
            System.out.println("==== " + classLabel.value() + "信息 ====");
        }

        Field[] fields = clazz.getDeclaredFields();

        try {
            for (Field field : fields) {

                field.setAccessible(true);

                Label label = field.getAnnotation(Label.class);
                if (label == null) continue;

                Object value = field.get(person);

                System.out.println(label.value() + "：" + value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return person;
    }
}